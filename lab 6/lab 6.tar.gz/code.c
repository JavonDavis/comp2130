#include <stdio.h>

int main(int argc, char * argv[])
{
	system("sort code.c > sorted-code");
}