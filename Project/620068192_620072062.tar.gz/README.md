Student ID numbers:
620068192
620072062

# Socket-programming-p2p
Program that allows for clients to connect to a server then request to talk to each other. Clients can also send messages within 2 predefined groups.

Compile both the server client c files. Start the server then start as many clients as you'd like. An instruction menu is provided at the beginning displaying a list of commands.

max # of clients:10

#Usage
	Commands:
	\l - view available clients
	\c - to communicate with a client
    \w - to subscribe to working group
    \f - to subscribe to fun group
    \sw - to send a broadcast to working group
    \sf - to send a broadcast to fun group
    \qw - to exit the working group
    \qf - to exit the fun group
	\q - Exit

